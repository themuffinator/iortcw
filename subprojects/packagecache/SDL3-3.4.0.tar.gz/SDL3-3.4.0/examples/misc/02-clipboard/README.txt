This example code lets the user copy and paste with the system clipboard.

This only handles text, but SDL supports other data types, too.

Note that only Chrome-based browsers support this API currently. This uses a
new Javascript API, so hopefully this will be available everywhere soon!
