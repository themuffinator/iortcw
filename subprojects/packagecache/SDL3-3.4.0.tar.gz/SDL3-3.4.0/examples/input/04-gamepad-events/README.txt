This example code looks for gamepad input in the event handler, and
reports any changes as a flood of info.
